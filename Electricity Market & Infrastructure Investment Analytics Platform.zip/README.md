# Elecora — Electricity Market & Infrastructure Investment Analytics Platform

Elecora is a full-stack Flask + SQLite platform combining **EEE power-market concepts with MBA finance and investment analysis**. It evaluates electricity infrastructure projects using generation assumptions, tariffs, operating costs, CAPEX, NPV, IRR and payback.

## Features
- Power project portfolio management
- Solar, wind and hybrid project modeling
- Electricity market price tracking
- Peak/off-peak market analysis
- Generation estimation
- Revenue and OPEX modeling
- NPV, IRR and payback calculation
- Investment scenario comparison
- Capital expenditure portfolio view
- Executive dashboard

## Technology
Python, Flask, SQLite, Jinja2, HTML5, CSS3

## Run
```bash
pip install -r requirements.txt
python app.py
```
Open `http://127.0.0.1:5000`.

## Core Model
Annual generation (MWh) = Capacity (MW) × 8,760 × Utilization % / 100

Annual revenue = Generation (MWh) × Tariff × 1,000

Annual cash flow = Revenue − OPEX

NPV = −CAPEX + Σ Cash Flow / (1 + discount rate)^year

The demonstration model uses a 10% discount rate. IRR is solved numerically from the projected annual cash flows.

## Portfolio Value
Elecora demonstrates the intersection of electrical engineering, energy economics, financial modeling, capital allocation and strategic investment analysis.

## Future Enhancements
- Hourly load curves
- Power-market forecasting
- Battery dispatch optimization
- PPA contract modeling
- Grid congestion analysis
- Renewable intermittency simulation
- Carbon-credit economics
- Monte Carlo project risk analysis
- Interactive charts and exports

## Author
Snehil Raj — B.Tech EEE, VIT Vellore
