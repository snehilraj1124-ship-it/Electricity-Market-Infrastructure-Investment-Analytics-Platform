from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3, math
from datetime import datetime

app=Flask(__name__)
app.secret_key="elecora-secret"
DB="elecora.db"

def db():
    c=sqlite3.connect(DB)
    c.row_factory=sqlite3.Row
    return c

def init_db():
    c=db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS projects(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, technology TEXT NOT NULL,
      capacity_mw REAL NOT NULL, capex REAL NOT NULL, opex REAL NOT NULL,
      tariff REAL NOT NULL, utilization REAL NOT NULL, life_years INTEGER NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS investments(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id INTEGER NOT NULL, scenario TEXT NOT NULL,
      tariff REAL NOT NULL, utilization REAL NOT NULL,
      annual_revenue REAL NOT NULL, annual_opex REAL NOT NULL,
      annual_cashflow REAL NOT NULL, npv REAL NOT NULL,
      irr REAL NOT NULL, payback REAL NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY(project_id) REFERENCES projects(id)
    );
    CREATE TABLE IF NOT EXISTS market_prices(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      market TEXT NOT NULL, peak_price REAL NOT NULL,
      offpeak_price REAL NOT NULL, demand_gwh REAL NOT NULL,
      recorded_on TEXT NOT NULL
    );
    """)
    if c.execute("SELECT COUNT(*) FROM projects").fetchone()[0]==0:
        c.executemany("""INSERT INTO projects
        (name,technology,capacity_mw,capex,opex,tariff,utilization,life_years,created_at)
        VALUES (?,?,?,?,?,?,?,?,?)""",[
        ("Delhi Solar Cluster","Solar",50,275000000,7000000,5.20,22,25,"2026-09-01"),
        ("Industrial Wind Park","Wind",80,520000000,13500000,4.80,32,25,"2026-09-02"),
        ("Rooftop Storage Hybrid","Solar + Battery",20,180000000,5500000,6.10,28,15,"2026-09-03")
        ])
    if c.execute("SELECT COUNT(*) FROM market_prices").fetchone()[0]==0:
        c.executemany("""INSERT INTO market_prices
        (market,peak_price,offpeak_price,demand_gwh,recorded_on) VALUES (?,?,?,?,?)""",[
        ("North Zone",8.40,4.10,1840,"2026-09-18"),
        ("West Zone",7.90,3.80,1620,"2026-09-19"),
        ("South Zone",9.10,4.50,2010,"2026-09-20")
        ])
    c.commit(); c.close()

def npv(cashflow, capex, rate, years):
    return -capex + sum(cashflow/((1+rate)**y) for y in range(1,years+1))

def irr(cashflow, capex, years):
    lo,hi=-0.95,2.0
    for _ in range(100):
        r=(lo+hi)/2
        val=-capex+sum(cashflow/((1+r)**y) for y in range(1,years+1))
        if val>0: lo=r
        else: hi=r
    return (lo+hi)/2*100

def metrics(p, tariff=None, utilization=None):
    tariff = p["tariff"] if tariff is None else tariff
    utilization = p["utilization"] if utilization is None else utilization
    generation=p["capacity_mw"]*8760*utilization/100
    revenue=generation*1000*tariff
    opex=p["opex"]
    cash=revenue-opex
    rate=.10
    value=npv(cash,p["capex"],rate,p["life_years"])
    rate_irr=irr(cash,p["capex"],p["life_years"])
    payback=p["capex"]/cash if cash>0 else 999
    return generation,revenue,opex,cash,value,rate_irr,payback

@app.route("/")
def dashboard():
    c=db()
    projects=c.execute("SELECT * FROM projects ORDER BY id DESC").fetchall()
    investments=c.execute("""SELECT i.*,p.name project_name FROM investments i
      JOIN projects p ON p.id=i.project_id ORDER BY i.npv DESC""").fetchall()
    market=c.execute("SELECT * FROM market_prices ORDER BY id DESC").fetchall()
    stats={
      "projects":len(projects),
      "investments":len(investments),
      "capex":c.execute("SELECT COALESCE(SUM(capex),0) FROM projects").fetchone()[0],
      "avg_irr":c.execute("SELECT COALESCE(AVG(irr),0) FROM investments").fetchone()[0]
    }
    c.close()
    return render_template("dashboard.html",projects=projects,investments=investments,market=market,stats=stats)

@app.route("/projects")
def projects():
    c=db(); rows=c.execute("SELECT * FROM projects ORDER BY id DESC").fetchall(); c.close()
    return render_template("projects.html",projects=rows)

@app.route("/projects/new",methods=["GET","POST"])
def project_new():
    if request.method=="POST":
        try:
            vals=(request.form["name"].strip(),request.form["technology"].strip(),
                  float(request.form["capacity_mw"]),float(request.form["capex"]),
                  float(request.form["opex"]),float(request.form["tariff"]),
                  float(request.form["utilization"]),int(request.form["life_years"]),
                  datetime.now().strftime("%Y-%m-%d"))
            if not vals[0] or not vals[1] or vals[2]<=0 or vals[3]<0 or vals[4]<0 or vals[5]<=0 or not 0<vals[6]<=100 or vals[7]<=0: raise ValueError
            c=db(); c.execute("""INSERT INTO projects
            (name,technology,capacity_mw,capex,opex,tariff,utilization,life_years,created_at)
            VALUES (?,?,?,?,?,?,?,?,?)""",vals); c.commit(); c.close()
            flash("Project added successfully.","success"); return redirect(url_for("projects"))
        except (ValueError,KeyError):
            flash("Enter valid project values.","error")
    return render_template("forms.html",form_type="project")

@app.route("/market")
def market():
    c=db(); rows=c.execute("SELECT * FROM market_prices ORDER BY id DESC").fetchall(); c.close()
    return render_template("market.html",market=rows)

@app.route("/market/new",methods=["GET","POST"])
def market_new():
    if request.method=="POST":
        try:
            vals=(request.form["market"].strip(),float(request.form["peak_price"]),
                  float(request.form["offpeak_price"]),float(request.form["demand_gwh"]),
                  request.form["recorded_on"] or datetime.now().strftime("%Y-%m-%d"))
            if not vals[0] or min(vals[1],vals[2],vals[3])<0: raise ValueError
            c=db(); c.execute("""INSERT INTO market_prices
            (market,peak_price,offpeak_price,demand_gwh,recorded_on) VALUES (?,?,?,?,?)""",vals)
            c.commit(); c.close(); flash("Market record added.","success"); return redirect(url_for("market"))
        except (ValueError,KeyError):
            flash("Enter valid market data.","error")
    return render_template("forms.html",form_type="market")

@app.route("/investments")
def investments():
    c=db(); rows=c.execute("""SELECT i.*,p.name project_name,p.technology
      FROM investments i JOIN projects p ON p.id=i.project_id ORDER BY i.npv DESC""").fetchall()
    c.close(); return render_template("investments.html",investments=rows)

@app.route("/investments/new",methods=["GET","POST"])
def investment_new():
    c=db(); projects=c.execute("SELECT * FROM projects ORDER BY name").fetchall(); c.close()
    if request.method=="POST":
        try:
            pid=int(request.form["project_id"]); scenario=request.form["scenario"].strip()
            tariff=float(request.form["tariff"]); util=float(request.form["utilization"])
            p=next((x for x in projects if x["id"]==pid),None)
            if not p or not scenario or tariff<=0 or not 0<util<=100: raise ValueError
            generation,revenue,opex,cash,value,rate_irr,payback=metrics(p,tariff,util)
            c=db(); c.execute("""INSERT INTO investments
            (project_id,scenario,tariff,utilization,annual_revenue,annual_opex,
             annual_cashflow,npv,irr,payback,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (pid,scenario,tariff,util,revenue,opex,cash,value,rate_irr,payback,
             datetime.now().strftime("%Y-%m-%d %H:%M")))
            c.commit(); c.close(); flash("Investment scenario calculated.","success")
            return redirect(url_for("investments"))
        except (ValueError,KeyError):
            flash("Enter valid investment assumptions.","error")
    return render_template("forms.html",form_type="investment",projects=projects)

@app.route("/investments/<int:iid>")
def investment_detail(iid):
    return redirect(url_for("investments"))

if __name__=="__main__":
    init_db()
    app.run(debug=True)
